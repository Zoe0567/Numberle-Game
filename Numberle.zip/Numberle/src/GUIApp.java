import javax.swing.*;

/**
 * GUI version of numberle game.
 */
public class GUIApp {

    /**
     * Main class of the GUI version.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(
                GUIApp::createAndShowGUI
        );
    }

    /**
     * Creates and show GUI.
     */
    public static void createAndShowGUI() {
        
        INumberleModel model = new NumberleModel(); // Create a new instance of the NumberleModel.
        NumberleController controller = new NumberleController(model); // Create a new instance of the NumberleController.
        new NumberleView(model, controller); // Create a new instance of the NumberleView.
    }
}
