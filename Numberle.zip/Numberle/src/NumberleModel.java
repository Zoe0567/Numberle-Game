import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;


public class NumberleModel extends Observable implements INumberleModel {
    private String targetNumber;               // Declare the target number.
    private StringBuilder currentGuess;        // Declare the current guessof the player.
    private int remainingAttempts;             // The remaining attempts times.
    private boolean gameWon;                   // Whether the game is won.

    private final Set<String> greyLetters = new HashSet<>();    // A set of not the target characters.
    private final Set<String> yellowLetters = new HashSet<>();  // A set of the target characters with incorrect position.
    private final Set<String> greenLetters = new HashSet<>();   // A set of the target characters with correct position.
    public char symbolMatched = '√';             // Represent the target character with correct position.
    public char symbolNotInThePlace = '?';       // Represent the target character with incorrect position.
    public char symbolNotExist = 'x';            // Represent the non target character.

    /**
     * Initializes the game with default settings.
     */
    @Override
    public void initialize() {
        if (!FLAG_RANDOM_SELECT) {
            targetNumber = "3*2=1+5"; // Default target number if random selection is disabled
        } else {
            Set<String> equations = readFile();
            Random rand = new Random(); // Randomly selects a target number from the set of equations
            int index = rand.nextInt(equations.size());
            targetNumber = new ArrayList<>(equations).get(index); 
        }

        currentGuess = new StringBuilder("       ");  // Initializes the current guess
        remainingAttempts = MAX_ATTEMPTS;   // Sets the remaining attempts to maximum
        gameWon = false;   // Initializes the game as lost
        setChanged();
        notifyObservers();

    }

    /**
     * Processes the player input guess.
     */
    @Override
    public boolean processInput(String input) {
        if (FLAG_SHOW_ERROR_EQUATION) {
            if (!validEquation(input)) {
                return false;
            }
        }

        char[] targetArray = targetNumber.toCharArray();
        char[] inputArray = input.toCharArray();

        for (int i = 0; i < targetArray.length; i++) {
            if (targetArray[i] == inputArray[i]) {
                currentGuess.setCharAt(i, symbolMatched);   // Sets the symbol for a character in the correct position
                greenLetters.add(String.valueOf(inputArray[i]));   // Adds the character to the set of characters in the correct position
            } else if (targetNumber.contains(String.valueOf(inputArray[i]))) {
                currentGuess.setCharAt(i, symbolNotInThePlace);   // Sets the symbol for a character in the target number but not in the correct position
                yellowLetters.add(String.valueOf(inputArray[i]));   // Adds the character to the set of characters not in the correct position
            } else {
                currentGuess.setCharAt(i, symbolNotExist);   // Sets the symbol for a character not in the target number
                greyLetters.add(String.valueOf(inputArray[i]));   // Adds the character to the set of characters not in the target number
            }
        }
        remainingAttempts--;   // Decreases the remaining attempts

        if (currentGuess.toString().equals("√".repeat(EQUATION_LENGTH))) {
            gameWon = true;   // If the current guess matches the target number, the game is won
        }
        setChanged();
        notifyObservers();

        return true;
    }

    /**
     * Checks if the game is over.
     */
    @Override
    public boolean isGameOver() {
        return remainingAttempts <= 0 || gameWon; // Returns true if the remaining attempts are zero or the game has been won
    }

    /**
     * Checks if the game is won.
     */
    @Override
    public boolean isGameWon() {
        return gameWon; // Returns true if the game has been won
    }

    /**
     * Gets the target number that the player needs to guess.
     */
    @Override
    public String getTargetNumber() {
        return targetNumber;  // Returns the target number
    }

    /**
     * Gets the current guess made by the player.
     */
    @Override
    public StringBuilder getCurrentGuess() {
        return currentGuess; // Returns the current guess
    }

    /**
     * Gets the number of remaining attempts for the player.
     */
    @Override
    public int getRemainingAttempts() {
        return remainingAttempts;   // Returns the number of remaining attempts
    }

    /**
     * Starts a new game with default settings.
     */
    @Override
    public void startNewGame() {
        initialize();   // Starts a new game by reinitializing the model
    }

    /**
     * Gets the set of grey letters in the current guess.
     */
    @Override
    public Set<String> getGreyLetters() {
        return greyLetters;   // Returns the set of characters not in the target number
    }

    /**
     * Gets the set of gold letters in the current guess.
     */
    @Override
    public Set<String> getYellowLetters() {
        return yellowLetters;   // Returns the set of characters in the target number but not in the correct position
    }

    /**
     * Gets the set of green letters in the current guess.
     */
    @Override
    public Set<String> getGreenLetters() {
        return greenLetters;   // Returns the set of characters in the correct position
    }

    /**
     * Reads equations from a file and returns them as a set of strings.
     */
    private Set<String> readFile() {
        Set<String> result = new HashSet<>(); // Create a new HashSet to store the read equations.
        try {
            Scanner sc = new Scanner(new File(GUESS_EQUATIONS_FILE));// Create a new Scanner to read the file.
            while (sc.hasNextLine()) {  // Iterate over each line in the file. 
                String line = sc.nextLine().strip(); // Read the next line and remove leading/trailing whitespace.
                if (!line.isEmpty()) { // Check if the line is not empty.
                    result.add(line); // Add the non-empty line to the set of equations.
                }
            }
        } catch (FileNotFoundException e) { // Handle the case where the file is not found.
            e.printStackTrace(); // Print the error stack trace.
        }
        return result; // Return the set of non-empty equations.
    }

    /**
     * Checks if the provided equation is valid.
     */
    private boolean validEquation(String equation) {
        //If any of these conditions are not met, the method returns false.
        if (equation.length() != 7 || !equation.contains("=")) {
            return false;
        }

        // The equation should not have "=" as the first or last character.
        if (equation.charAt(0) == '=' || equation.charAt(6) == '=') {
            return false;
        }

        String[] parts = equation.split("="); // Split the equation into two parts: left expression and right expression.
        String leftExpression = parts[0]; // Extract the left expression.
        String rightExpression = parts[1]; // Extract the right expression.

        System.out.println("----------------------------------------\n"+"Left Expression: " + leftExpression); // Print the left expression for debugging.
        System.out.println("Right Expression: " + rightExpression); // Print the right expression for debugging.

        // Evaluate the left and right expressions and check if their values are equal.
        return evaluateExpression(leftExpression) == evaluateExpression(rightExpression);
    }

    /**
     * Evaluates the value of a mathematical expression.
     */
    private int evaluateExpression(String expression) {
        int result = 0; // Stores the final result of the expression.
        int num = 0; // Stores the currently parsed number.
        int prevNum = 0; // Stores the previous number in the expression.
        char operator = '+'; // Stores the current operator.
        char prevOperator = '+'; // Stores the previous operator.

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i); // Get the current character in the expression.

            if (Character.isDigit(c)) { // Check if the character is a digit.
                num = num * 10 + (c - '0'); // Accumulate the digit to form a number.
            } else if (c == '+' || c == '-') { // Check if the character is an addition or subtraction operator.
                // Apply the previous operator to the previous number.
                if (prevOperator == '*') {
                    prevNum *= num;
                } else if (prevOperator == '/') {
                    if (num == 0) {
                        throw new ArithmeticException("Division by zero"); // Division by zero is not allowed.
                    }
                    prevNum /= num;
                } else {
                    prevNum = num;
                }

                // Apply the current operator to the accumulated result.
                if (operator == '+') {
                    result += prevNum;
                } else {
                    result -= prevNum;
                }

                // Update the operators and reset the number.
                operator = c;
                prevOperator = '+';
                num = 0;
            } else if (c == '*' || c == '/') { // Check if the character is a multiplication or division operator.
                // Apply the previous multiplication or division if any.
                if (prevOperator == '*') {
                    prevNum *= num;
                } else if (prevOperator == '/') {
                    if (num == 0) {
                        throw new ArithmeticException("Division by zero"); // Division by zero is not allowed.
                    }
                    prevNum /= num;
                } else {
                    prevNum = num;
                }

                // Update the previous operator to the current one and reset the number.
                prevOperator = c;
                num = 0;
            }
        }

        // Apply the last number with the last operator
        if (prevOperator == '*') {
            prevNum *= num;
        } else if (prevOperator == '/') {
            if (num == 0) {
                // Division by zero is not allowed.
                throw new ArithmeticException("Division by zero");
            }
            prevNum /= num;
        } else {
            prevNum = num;
        }

        // Apply the final result with the last operator
        if (operator == '+') {
            result += prevNum;
        } else {
            result -= prevNum;
        }

        return result;
    }

}
