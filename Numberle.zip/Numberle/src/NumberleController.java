public class NumberleController {
    private final INumberleModel model;

    /**
     * Constructs a NumberleController object.
     */
    public NumberleController(INumberleModel model) {
        this.model = model;
    }

    /**
     * Sets controller view.
     */
    public void setView() {}

    /**
     * Processes the player input guess.
     */
    public boolean processInput(String input) {
        return !model.processInput(input);
    }

    /**
     * Checks if the game is over.
     */
    public boolean isGameOver() {
        return model.isGameOver();
    }

    /**
     * Checks if the game is won.
     */
    public boolean isGameWon() {
        return model.isGameWon();
    }

    /**
     * Gets the target number of the equation.
     */
    public String getTargetEquation() {
        return model.getTargetNumber();
    }

    /**
     * Gets the current guess of the player.
     */
    public StringBuilder getCurrentGuess() {
        return model.getCurrentGuess();
    }

    /**
     * Gets the number of remaining attempts for the player.
     */
    public int getRemainingAttempts() {
        return model.getRemainingAttempts();
    }

    /**
     * Starts a new game.
     */
    public void startNewGame() {
        model.startNewGame();
    }
}