import java.util.Set;

/**
 *Defines the basic behavior of the Numberle model.
 */
public interface INumberleModel {
    int MAX_ATTEMPTS = 6; // Maximum attempt times
    int EQUATION_LENGTH = 7; // Length of the equation
    String GUESS_EQUATIONS_FILE = "equations.txt"; // Store the possible guessed equations
    boolean FLAG_SHOW_ERROR_EQUATION = true; // Show incorrect equations
    boolean FLAG_RANDOM_SELECT = true; // Select equations randomly


    void initialize(); //Initializes the game model.

    boolean processInput(String input); //user input return true if it is valid, otherwise false

    boolean isGameOver(); //Return true if the game is over, otherwise false

    boolean isGameWon(); //Return true if the game is won, otherwise false

    String getTargetNumber(); //Get the target number.

    StringBuilder getCurrentGuess(); //Get the current guess equation.

    int getRemainingAttempts(); //Get the remaining attempts.

    void startNewGame(); //Starts a new game.

    Set<String> getGreyLetters(); //Get the set of grey letters.
 
    Set<String> getYellowLetters(); //Get the set of yellow letters.

    Set<String> getGreenLetters(); //Get the set of green letters.
    
}