import java.util.Scanner;

/**
 * CLI version of numberle game.
 */
public class CLIApp {
    private final INumberleModel model; // Managing the game state and processing user input.
    private final Scanner scanner;

    /**
     * Constructs a CLIApp object.
     */
    public CLIApp() {
        model = new NumberleModel(); // Create a new instance.
        scanner = new Scanner(System.in);
    }

    /**
     * Displays rules, process input.
     */
    public void startGame() {
        // Display rules.
        System.out.println("""
                ----------------------------------------
                Welcome to Numberle!
                You have to guess the hidden math equation in 6 tries.
                Game Rules:
                    The guess is accepted only with the correct equation
                    Each guess must contain one “=”
                    You can only use 1 2 3 4 5 6 7 8 9 0 numbers and + - * / = signs
                    The equation must have an integer to the right of the "="
                    Guesses are not commutative (a+b=c and b+a=c are different answers)
                To start playing, enter any mathematical equation.
                ----------------------------------------""");

        model.startNewGame(); // Initialize a new game.

        while (!model.isGameOver()) {
            System.out.println("There are " + model.getRemainingAttempts()+"/6 attempts times remained"); // Prompt the user for their guess and process it
            System.out.print("Enter equation: ");
            String guess = scanner.nextLine();

            boolean valid = model.processInput(guess);

            if (valid) {
                System.out.println("----------------------------------------\nThis is the hint of your guess: \n\n                    " + model.getCurrentGuess().toString()+"\n\n√ : digit or operator exists and correct position;"+
                        "\n? : digit or operator exists but wrong position;"+
                        "\n× : digit or operator not exists."
                ); // Provide feedback to the user
            } else {
                System.out.println("Invalid equation.");
            }

            System.out.println("----------------------------------------");
        }

        if (model.isGameWon()) {
            System.out.println("You win!"); // Print won message
        } else {
            System.out.println("You Lost! The target equation was: " + model.getTargetNumber());
        }

        // Ask the user if they want to play again
        System.out.println("Do you want to play again? (yes/no)");
        String playAgain = scanner.nextLine();

        if (playAgain.equalsIgnoreCase("yes")) {
            startGame(); // Restart the game if the user wants to play again
        } else {
            System.out.println("Thanks for playing Numberle.");
        }
    }

    /**
     * The main entry point of the application.
     * Creates an instance of CLIApp and starts the game.
     *
     * @param args The command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        CLIApp game = new CLIApp(); // Create a new instance of CLIApp.
        game.startGame(); // Start the game by calling the startGame() method.
    }
}
